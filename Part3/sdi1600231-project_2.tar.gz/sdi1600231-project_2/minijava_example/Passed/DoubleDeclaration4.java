class DoubleDeclaration4 {

    public static void main(String[] args) {}

}


class A {


}


class B {


}


class A {


}