class UseArgs {

    public static void main(String[] args){
        int i;
        i = args;
    }

}
