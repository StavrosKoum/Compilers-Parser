class test73{
    public static void main(String[] a){
        System.out.println(new Test().start());
    }
}

class Test extends test73 {

    public int start(){
	
        return 0;
    }
}
